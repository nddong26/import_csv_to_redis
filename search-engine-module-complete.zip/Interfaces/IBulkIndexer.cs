using System.Collections.Generic;
using System.Threading.Tasks;

namespace SearchEngineModule.Interfaces
{
    public interface IBulkIndexer
    {
        Task BulkIndexAsync<T>(IEnumerable<(T Document, string Id)> documents, string indexName) where T : class;
    }
}
