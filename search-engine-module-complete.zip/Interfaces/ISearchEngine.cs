using System.Collections.Generic;
using System.Threading.Tasks;

namespace SearchEngineModule.Interfaces
{
    public interface ISearchEngine
    {
        Task IndexAsync<T>(T document, string id, string indexName) where T : class;
        Task DeleteAsync(string id, string indexName);
        Task<IEnumerable<T>> SearchAsync<T>(string query, string indexName, int page = 1, int pageSize = 10,
            IEnumerable<ISearchFilter>? filters = null,
            IEnumerable<ISearchSort>? sorts = null) where T : class;
        Task<T?> GetByIdAsync<T>(string id, string indexName) where T : class;
    }
}
