namespace SearchEngineModule.Interfaces
{
    public interface ISearchConnectionFactory<TClient>
    {
        TClient GetClient();
    }
}
