using System.Collections.Generic;

namespace SearchEngineModule.Interfaces
{
    public interface ISearchResult<T>
    {
        IEnumerable<T> Items { get; }
        long Total { get; }
        int Page { get; }
        int PageSize { get; }
    }
}
