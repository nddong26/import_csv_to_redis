namespace SearchEngineModule.Interfaces
{
    public interface ISearchFilter
    {
        string Field { get; }
        string Value { get; }
        string Operator { get; } // eq, gt, lt, contains, etc.
    }
}
