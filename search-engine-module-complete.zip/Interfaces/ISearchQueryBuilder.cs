using System.Collections.Generic;

namespace SearchEngineModule.Interfaces
{
    public interface ISearchQueryBuilder<TClient>
    {
        object BuildQuery(string query,
            IEnumerable<ISearchFilter>? filters = null,
            IEnumerable<ISearchSort>? sorts = null);
    }
}
