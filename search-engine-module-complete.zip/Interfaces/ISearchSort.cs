namespace SearchEngineModule.Interfaces
{
    public interface ISearchSort
    {
        string Field { get; }
        bool Ascending { get; }
    }
}
