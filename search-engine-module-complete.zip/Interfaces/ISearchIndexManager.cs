using System.Threading.Tasks;

namespace SearchEngineModule.Interfaces
{
    public interface ISearchIndexManager
    {
        Task<bool> CreateIndexAsync(string indexName, object? mapping = null);
        Task<bool> DeleteIndexAsync(string indexName);
        Task<bool> IndexExistsAsync(string indexName);
    }
}
