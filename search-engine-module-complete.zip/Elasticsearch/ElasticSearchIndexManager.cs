using Nest;
using SearchEngineModule.Interfaces;
using System.Threading.Tasks;

namespace SearchEngineModule.Elasticsearch
{
    public class ElasticSearchIndexManager : ISearchIndexManager
    {
        private readonly IElasticClient _client;

        public ElasticSearchIndexManager(ISearchConnectionFactory<IElasticClient> factory)
        {
            _client = factory.GetClient();
        }

        public async Task<bool> CreateIndexAsync(string indexName, object? mapping = null)
        {
            var response = await _client.Indices.CreateAsync(indexName, c => c.Map(m => m.AutoMap()));
            return response.IsValid;
        }

        public async Task<bool> DeleteIndexAsync(string indexName)
        {
            var response = await _client.Indices.DeleteAsync(indexName);
            return response.IsValid;
        }

        public async Task<bool> IndexExistsAsync(string indexName)
        {
            var response = await _client.Indices.ExistsAsync(indexName);
            return response.Exists;
        }
    }
}
