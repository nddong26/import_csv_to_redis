using Nest;
using SearchEngineModule.Interfaces;
using System.Collections.Generic;

namespace SearchEngineModule.Elasticsearch
{
    public class ElasticSearchQueryBuilder : ISearchQueryBuilder<IElasticClient>
    {
        public object BuildQuery(string query, IEnumerable<ISearchFilter>? filters = null, IEnumerable<ISearchSort>? sorts = null)
        {
            var mustQueries = new List<QueryContainer>();

            if (!string.IsNullOrEmpty(query))
            {
                mustQueries.Add(new QueryStringQuery { Query = query });
            }

            if (filters != null)
            {
                foreach (var f in filters)
                {
                    mustQueries.Add(new TermQuery { Field = f.Field, Value = f.Value });
                }
            }

            return new BoolQuery { Must = mustQueries };
        }
    }
}
