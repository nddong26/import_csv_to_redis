using Nest;
using SearchEngineModule.Interfaces;
using System;

namespace SearchEngineModule.Elasticsearch
{
    public class ElasticSearchConnectionFactory : ISearchConnectionFactory<IElasticClient>
    {
        private readonly IElasticClient _client;

        public ElasticSearchConnectionFactory(string url, string defaultIndex)
        {
            var settings = new ConnectionSettings(new Uri(url))
                .DefaultIndex(defaultIndex);

            _client = new ElasticClient(settings);
        }

        public IElasticClient GetClient() => _client;
    }
}
