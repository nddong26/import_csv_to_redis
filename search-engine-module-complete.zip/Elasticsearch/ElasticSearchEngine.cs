using Nest;
using SearchEngineModule.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SearchEngineModule.Elasticsearch
{
    public class ElasticSearchEngine : ISearchEngine
    {
        private readonly IElasticClient _client;
        private readonly ISearchQueryBuilder<IElasticClient> _queryBuilder;

        public ElasticSearchEngine(ISearchConnectionFactory<IElasticClient> factory,
                                   ISearchQueryBuilder<IElasticClient> queryBuilder)
        {
            _client = factory.GetClient();
            _queryBuilder = queryBuilder;
        }

        public async Task IndexAsync<T>(T document, string id, string indexName) where T : class
        {
            await _client.IndexAsync(document, i => i.Index(indexName).Id(id));
        }

        public async Task DeleteAsync(string id, string indexName)
        {
            await _client.DeleteAsync<T>(id, d => d.Index(indexName));
        }

        public async Task<IEnumerable<T>> SearchAsync<T>(string query, string indexName, int page = 1, int pageSize = 10,
            IEnumerable<ISearchFilter>? filters = null,
            IEnumerable<ISearchSort>? sorts = null) where T : class
        {
            var builtQuery = _queryBuilder.BuildQuery(query, filters, sorts);

            var response = await _client.SearchAsync<T>(s => s
                .Index(indexName)
                .From((page - 1) * pageSize)
                .Size(pageSize)
                .Query(q => (QueryContainer)builtQuery)
            );

            return response.Documents;
        }

        public async Task<T?> GetByIdAsync<T>(string id, string indexName) where T : class
        {
            var response = await _client.GetAsync<T>(id, g => g.Index(indexName));
            return response.Found ? response.Source : null;
        }
    }
}
