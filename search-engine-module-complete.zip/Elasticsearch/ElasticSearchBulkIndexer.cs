using Nest;
using SearchEngineModule.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SearchEngineModule.Elasticsearch
{
    public class ElasticSearchBulkIndexer : IBulkIndexer
    {
        private readonly IElasticClient _client;

        public ElasticSearchBulkIndexer(ISearchConnectionFactory<IElasticClient> factory)
        {
            _client = factory.GetClient();
        }

        public async Task BulkIndexAsync<T>(IEnumerable<(T Document, string Id)> documents, string indexName) where T : class
        {
            var bulkRequest = new BulkRequest(indexName)
            {
                Operations = new List<IBulkOperation>()
            };

            foreach (var (doc, id) in documents)
            {
                bulkRequest.Operations.Add(new BulkIndexOperation<T>(doc) { Id = id });
            }

            await _client.BulkAsync(bulkRequest);
        }
    }
}
